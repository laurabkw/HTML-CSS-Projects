﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.MySql.Aula2.Models
{
    public class Estado
    {
        //torna a coluna sigla a coluna chave(coluna única da tabela)
        [Key]
        //torna obrogatório informar 2 chars(caractéres)
        [StringLength(2, MinimumLength = 2, ErrorMessage = "Informe 2 caractéres")]
        public string Sigla { get; set; }
        //torna obrigatório o preenchimento do campo nome
        [Required(ErrorMessage = "O campo nome é obrigatório")]
        [StringLength(200, MinimumLength = 3, ErrorMessage = "O campo nome deve conter entre 3 e 200 caractéres")]
        public string Nome { get; set; }

    }
}
