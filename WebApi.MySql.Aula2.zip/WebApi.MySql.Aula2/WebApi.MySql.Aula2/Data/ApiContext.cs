﻿using Microsoft.EntityFrameworkCore;
using WebApi.MySql.Aula2.Models;

namespace WebApi.MySql.Aula2.Data
{
    //classe de contexto que herda as características DbContext
    public class ApiContext : DbContext
    {
        //construtor da classe de contexto do banco de dados
        public ApiContext(DbContextOptions<ApiContext> opt) : base(opt)
        {

        }

        //criar os DbSet de cada tabela do sistema
        //DbSet é a coleção que representa a tabela no banco de dados
        public DbSet<Estado> Estados { get; set; }  
    }
}
